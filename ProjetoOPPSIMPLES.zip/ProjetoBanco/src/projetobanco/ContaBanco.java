
package projetobanco;

//classe para conta do banco
public class ContaBanco {
    
    //criando variaveis
    public int numConta;
    protected char tipo;
    private String dono;
    private double saldo;
    private boolean status;
    
    public ContaBanco()
    {
      saldo = 0;
      status = false;
    }
    
    //definindo getters e setters
    public void setNumConta(int numConta) {
        this.numConta = numConta;
    }

    public void setTipo(char tipo) {
        this.tipo = tipo;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
    
    public int getNumConta() {
        return numConta;
    }

    public char getTipo() {
        return tipo;
    }

    public String getDono() {
        return dono;
    }

    public double getSaldo() {
        return saldo;
    }

    public boolean isStatus() {
        return status;
    }
    
    //criando metodos
    public void abrirConta(char C)
    { 
      setTipo (C);
      if (this.tipo == 'c')
      {
          setSaldo (getSaldo() + 50); //se abrir uma conta corrente ganha 50 reais de bonus
          //outro metodo para a instrução acima é ''this.saldo = this.saldo + 50'';
          setStatus (true);
      }
      else if (this.tipo == 'p')
      {
          setSaldo (getSaldo() + 150); //se abrir uma conta poupança ganha 150 reais de bonus
          setStatus (true);
      }
      else 
      {
          System.out.println("Erro!");
      }
    }
    public void fecharConta()
    {
        if (this.saldo>0) //verifica se a pessoa tem saldo antes de fechar a conta
        {
            System.out.println("Não será possivel concluir o fechamento da conta! \nMotivo: Há dinheiro disponivel ainda!");
        }
        else if (this.saldo<0) //verifica se a pessoa está devendo para o banco antes de fechar a conta
        {
            System.out.println("Não será possivel concluir o fechamento da conta! \nMotivo: Há um saldo negativo na conta \nResolução: Depositar a quantia necessaria!");
        }
        else //fecha a conta caso esteja tudo certo!
        {
            setDono("VAZIO!");
            setNumConta(0);
            setStatus(false);
            System.out.println("Fechamento de conta realizado com sucesso!");
        }
    }
    public void depositar (double valor) 
    {
      if (this.status = true) //verificando se a conta esta aberta
      {
       setSaldo (getSaldo() + valor);
          System.out.println("Deposito realizado com sucesso!");
      }
      else 
      {
          System.out.println("Erro. Não uma conta aberta!"); //da erro case a conta não esteja aberta
      }
    }
    public void sacar(double valors)
    {
      if (this.status = true) //verificando se a conta esta aberta
      {
        if (getSaldo()>=valors) //verificando se o saldo é maior ou igual que o valor do saque
                {
                 setSaldo (getSaldo()-valors);
                    System.out.println("Saque realizado com sucesso!");
                }  
        else 
        {
            System.out.println("Impossivel sacar o valor definido. \nMotivo: Saldo insuficiente!"); //da mensagem de erro se n houver o valor necessario para saque
        }
      }
      else 
      {
          System.out.println("Erro. Não uma conta aberta!"); //da erro case a conta não esteja aberta
      }
    }
    public void pagarMensal()
    {
        int mensal =0; //inicializa variavel em 0
        if (this.status == true) //verifica se a conta esta aberta
        {
        //verifica o tipo de conta para atribuir o valor da mensalidade
        if (this.tipo == 'c')
        {
            mensal = 12;
        }
        else if (this.tipo == 'p')
        {
         
            mensal =20;
        }
        //verifica se o saldo é maior que o valor da mensalidade
        if (getSaldo()>mensal)
        {
         setSaldo(getSaldo()-mensal);   
            System.out.println("Mensalidade paga com sucesso!");
        }
        else
        {
            System.out.println("Erro. Saldo insuficiente!"); //da erro caso não haja saldo suficiente para pagar mensalidade
        }
        }
        else
        {
            System.out.println("Erro. Não uma conta aberta!"); //da erro caso a conta não esteja aberta
        }
    }
    public void exibirstatus()
    {
        System.out.println("Status: "+ isStatus());
        System.out.println("Numero da conta: "+ getNumConta());
        System.out.println("Nome do titular: "+ getDono());
        System.out.println("Saldo: "+ getSaldo());
        System.out.println("Tipo da conta (C.Corrente e P.Poupança): "+getTipo());
    }
}
