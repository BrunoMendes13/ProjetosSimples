
package projetobanco;

import java.util.Scanner;


public class ProjetoBanco {

    
    public static void main(String[] args) {
    Scanner teclado1 = new Scanner (System.in); //obtendo metodo Scanner para entrada
        ContaBanco c1 = new ContaBanco(); //instanciando objeto Conta no Banco    
        int opc;
   
        do {
        System.out.println(" "); //espaçamento entre linhas 
        System.out.println("Digite a opção desejada: \n1. Abrir Conta \n2.Fechar Conta \n3.Depositar \n4.Sacar \n5.Pagar Mensalidade \n6.Exibir Status \n9.Fechar");
        opc = teclado1.nextInt();
        switch (opc){ //switch para o menu de opções
            
        case 1:
        System.out.println(" "); //espaçamento entre linhas
        Scanner teclado = new Scanner (System.in); //obtendo metodo scanner para outra entrada    
        char C; //criando variavel para parametro do tipo da conta
            System.out.println(" "); //espaçamento entre linhas
        System.out.println("Abertura de nova conta no BancoBruno (B&B)");
        do { //iniciando repetição para verificação
        System.out.println("Digite 'c' para corrente e 'p' para poupança:");
        C = teclado.nextLine().charAt(0); //usando o metodo CharAt para converte String para Char
        c1.abrirConta(C);
        } while ((C!='c') && (C!='p')); //finalizando repetiçao de verificação
        
        String nomed; //criando variavel para parametro do nome do dono da conta
        System.out.println("Digite o nome do responsavel pela conta:");
        nomed = teclado.nextLine();
        c1.setDono(nomed);
        
        int numc; //criando variavel para parametro do numero da conta
        System.out.println("Digite um numero para sua conta: (Lembre-se dele)");
        numc = teclado.nextInt();
        c1.setNumConta(numc);
        break;
        
        case 2:
            System.out.println(" "); //espaçamento entre linhas
            c1.fecharConta();
        break;
        
        case 3:
            System.out.println(" "); //espaçamento entre linhas
            Scanner teclado2 = new Scanner (System.in);
            System.out.println("Digite o valor que deseja depositar:");
            double valor = teclado2.nextDouble();
            c1.depositar(valor);
        break;  
        
        case 4:
            System.out.println(" "); //espaçamento entre linhas
            Scanner teclado3 = new Scanner (System.in);
            System.out.println("Digite o valor que deseja sacar:");
            double valorsac = teclado3.nextDouble();
            c1.sacar(valorsac);
        break;
            
        case 5:
            System.out.println(" "); //espaçamento entre linhas
            c1.pagarMensal();
        break;
        
        case 6:
        System.out.println(" "); //espaçamento entre linhas
        c1.exibirstatus();   
        break;
        
        default:
        System.out.println(" "); //espaçamento entre linhas    
        System.out.println("Digite uma opção valida!");
        break;
    }
    }while (opc !=9);
        }
    
}
